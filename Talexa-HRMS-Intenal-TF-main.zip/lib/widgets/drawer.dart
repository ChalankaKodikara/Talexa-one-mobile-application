import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:corehris/auth/authservices.dart';

import 'package:corehris/modules/HRMS/contactus/contact_us.dart';
import 'package:corehris/modules/HRMS/main_screens/dashboard/controllers/dash_con.dart';
import 'package:corehris/modules/HRMS/main_screens/subpages/settings_screen.dart';
import 'package:corehris/modules/HRMS/main_screens/subpages/viewprofile.dart';
import 'package:corehris/modules/HRMS/notifications/notification_screen.dart';
import 'package:corehris/modules/MASTER/start_page/start_con.dart';
import 'package:corehris/modules/MASTER/start_page/startpage.dart';
import 'package:corehris/modules/HRMS/lock_screen/screens/login_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// Simplified Talexa HRMS navigation drawer.
/// Uses the existing dashboard data and the existing LandingController.logout().
class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});

  @override
  State<MyDrawer> createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  late final LandingController landing;
  bool _signingOut = false;
  bool _modulesReady = false;
  int _accessibleModuleCount = 0;

  @override
  void initState() {
    super.initState();
    landing = Get.isRegistered<LandingController>()
        ? Get.find<LandingController>()
        : Get.put(LandingController());
    _readModuleAccess();
  }

  Future<void> _readModuleAccess() async {
    int count = 0;
    try {
      // systems_json is written during login and is the same source used
      // by LandingController.loadSystemsFromCache(). Do not use filteredServices:
      // it may be empty or affected by a previous dashboard search.
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('systems_json');
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          count = decoded.where((entry) {
            if (entry is! Map) return false;
            final url = entry['backend_url']?.toString().trim() ?? '';
            return url.isNotEmpty;
          }).length;
        }
      } else {
        // Fallback when running without a persisted login response.
        count = landing.services.where((s) => s['isAvailable'] == true).length;
      }
    } catch (error) {
      debugPrint('Drawer module access check failed: $error');
      count = landing.services.where((s) => s['isAvailable'] == true).length;
    }
    if (!mounted) return;
    setState(() {
      _accessibleModuleCount = count;
      _modulesReady = true;
    });
  }

  static const _blue = Color(0xFF1769E8);
  static const _ink = Color(0xFF182237);
  static const _muted = Color(0xFF7E8CA2);
  static const _line = Color(0xFFE8EDF5);

  void _open(BuildContext context, Widget Function() page) {
    Navigator.of(context).pop();
    Get.to(page,
        transition: Transition.cupertino,
        duration: const Duration(milliseconds: 300));
  }

  Future<void> _signOut() async {
    if (_signingOut) return;
    setState(() => _signingOut = true);
    try {
      // AuthService.logout clears the session and cached module list.
      // LandingController.logout() has a separate confirmation dialog,
      // so calling it here would lead to double confirmation and false
      // navigation after cancellation.
      await AuthService().logout();
      if (Get.isRegistered<LandingController>()) {
        landing.services.clear();
        landing.searchText.value = '';
      }
      Get.offAll(() => const LoginScreen());
    } catch (error) {
      Get.snackbar('Sign out failed', 'Please try again.');
    } finally {
      if (mounted) setState(() => _signingOut = false);
    }
  }

  void _confirmLogout(BuildContext context) {
    Navigator.of(context).pop();
    Get.dialog<void>(
      AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Sign out?',
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.w700, color: _ink)),
        content: const Text('Are you sure you want to sign out of Talexa HRMS?',
            style: TextStyle(fontSize: 13, height: 1.5, color: _muted)),
        actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel', style: TextStyle(color: _ink)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _blue,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: const StadiumBorder(),
            ),
            onPressed: () {
              Get.back();
              _signOut();
            },
            child: const Text('Sign out'),
          ),
        ],
      ),
      barrierDismissible: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final background = dark ? const Color(0xFF101623) : Colors.white;
    final titleColor = dark ? Colors.white : _ink;
    final dividerColor = dark ? Colors.white12 : _line;

    return Drawer(
      elevation: 0,
      width: MediaQuery.sizeOf(context).width * .84 > 340
          ? 340
          : MediaQuery.sizeOf(context).width * .84,
      backgroundColor: background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(28)),
      ),
      child: SafeArea(
        child: Column(
          children: [
            _ProfileHeader(dark: dark),
            Divider(height: 1, thickness: 1, color: dividerColor),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 24),
                children: [
                  if (_modulesReady && _accessibleModuleCount > 1) ...[
                    _SectionLabel('MAIN', dark: dark),
                    _NavItem(
                      icon: Icons.home_outlined,
                      title: 'Home',
                      onTap: () => _open(context, () => const LandingPage()),
                      dark: dark,
                    ),
                  ] else
                    _SectionLabel('MAIN', dark: dark),
                  _NavItem(
                    icon: Icons.person_outline_rounded,
                    title: 'Profile',
                    onTap: () => _open(context, () => const ViewProfile()),
                    dark: dark,
                  ),
                  const SizedBox(height: 22),
                  Divider(height: 1, color: dividerColor),
                  const SizedBox(height: 22),
                  _SectionLabel('PREFERENCES', dark: dark),
                  _NavItem(
                    icon: Icons.settings_outlined,
                    title: 'Settings',
                    onTap: () => _open(context, () => LogoutProfile()),
                    dark: dark,
                  ),
                  if (_modulesReady && _accessibleModuleCount > 1)
                    _NavItem(
                      icon: Icons.grid_view_outlined,
                      title: 'Main Menu',
                      onTap: () => _open(context, () => const LandingPage()),
                      dark: dark,
                    ),
                  _NavItem(
                    icon: Icons.notifications_none_rounded,
                    title: 'Notifications',
                    onTap: () => _open(context, () => NotificationScreen()),
                    dark: dark,
                  ),
                  const SizedBox(height: 22),
                  Divider(height: 1, color: dividerColor),
                  const SizedBox(height: 22),
                  _SectionLabel('SUPPORT', dark: dark),
                  _NavItem(
                    icon: Icons.headset_mic_outlined,
                    title: 'Contact Us',
                    onTap: () => _open(context, () => const ContactUs()),
                    dark: dark,
                  ),
                  const SizedBox(height: 12),
                  Divider(height: 1, color: dividerColor),
                  const SizedBox(height: 12),
                  _NavItem(
                    icon: Icons.logout_rounded,
                    title: 'Sign out',
                    onTap: () => _confirmLogout(context),
                    dark: dark,
                    danger: true,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 22),
              child: Text('Talexa HRMS  •  Smart workplace access',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10, color: dark ? Colors.white54 : _muted)),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text, {required this.dark});
  final String text;
  final bool dark;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 10, bottom: 10),
        child: Text(text,
            style: TextStyle(
                letterSpacing: 1.2,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: dark ? Colors.white54 : _MyDrawerState._muted)),
      );
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.title,
    required this.onTap,
    required this.dark,
    this.danger = false,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final bool dark;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final color = danger
        ? const Color(0xFFD64550)
        : (dark ? Colors.white : _MyDrawerState._ink);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          child: Row(
            children: [
              Icon(icon,
                  size: 22,
                  color: danger
                      ? color
                      : (dark ? Colors.white70 : _MyDrawerState._blue)),
              const SizedBox(width: 17),
              Expanded(
                child: Text(title,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: color)),
              ),
              if (!danger)
                Icon(Icons.chevron_right_rounded,
                    size: 20,
                    color: dark ? Colors.white38 : _MyDrawerState._muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileHeader extends StatefulWidget {
  const _ProfileHeader({required this.dark});
  final bool dark;

  @override
  State<_ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends State<_ProfileHeader> {
  late final DashboardController controller;
  String? cachedValue;
  ImageProvider? cachedImage;

  @override
  void initState() {
    super.initState();
    controller = Get.isRegistered<DashboardController>()
        ? Get.find<DashboardController>()
        : Get.put(DashboardController());
  }

  ImageProvider? _image(String value) {
    if (value == cachedValue) return cachedImage;
    cachedValue = value;
    try {
      if (value.isEmpty) return cachedImage = null;
      if (value.startsWith('http://') || value.startsWith('https://')) {
        return cachedImage = NetworkImage(value);
      }
      return cachedImage = MemoryImage(
          base64Decode(value.contains(',') ? value.split(',').last : value));
    } catch (_) {
      return cachedImage = null;
    }
  }

  @override
  Widget build(BuildContext context) => Obx(() {
        final name = controller.employeeName.value.trim();
        final username = controller.username.value.trim();
        final image = _image(controller.profileImageUrl.value ?? '');
        final dark = widget.dark;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              Navigator.of(context).pop();
              Get.to(() => const ViewProfile(),
                  transition: Transition.cupertino);
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 28, 20, 25),
              decoration: BoxDecoration(
                gradient: dark
                    ? const LinearGradient(
                        colors: [Color(0xFF17253B), Color(0xFF101623)])
                    : const LinearGradient(
                        colors: [Color(0xFFE5F1FF), Color(0xFFF7FAFF)]),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 29,
                    backgroundColor: const Color(0xFFD8E9FF),
                    backgroundImage: image,
                    child: image == null
                        ? const Icon(Icons.person_outline_rounded,
                            size: 28, color: _MyDrawerState._blue)
                        : null,
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name.isEmpty ? 'Welcome back' : name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color:
                                    dark ? Colors.white : _MyDrawerState._ink)),
                        const SizedBox(height: 4),
                        Text(username.isEmpty ? 'Your workspace' : username,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 12,
                                color: dark
                                    ? Colors.white60
                                    : _MyDrawerState._muted)),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_outward_rounded,
                      size: 19,
                      color: dark ? Colors.white70 : _MyDrawerState._blue),
                ],
              ),
            ),
          ),
        );
      });
}
