#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\src\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Chalanka-Files\Chalanka\Projects\A Organization\Talexa-HRMS-Intenal-TF-main"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Chalanka-Files\Chalanka\Projects\A Organization\Talexa-HRMS-Intenal-TF-main\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=6.1.9"
export "FLUTTER_BUILD_NUMBER=41"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
